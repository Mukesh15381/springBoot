package com.example.usingflyway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UsingflywayApplicationTests {

	@Test
	void contextLoads() {
	}

}
