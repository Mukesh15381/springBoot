package com.example.usingflyway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UsingflywayApplication {

	public static void main(String[] args) {
		SpringApplication.run(UsingflywayApplication.class, args);
	}

}
